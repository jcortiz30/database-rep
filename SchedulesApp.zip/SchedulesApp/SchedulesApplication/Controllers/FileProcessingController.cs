﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.IO;
using SchedulesApplication.Models;
using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;


namespace SchedulesApplication.Controllers
{
    public class FileProcessingController : Controller
    {

        private readonly DatabaseContext _context;

        public FileProcessingController(DatabaseContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }


        public IActionResult ProcessFile()
        {
            int rowsCounted = 0, rowsImported = 0, rowsBad = 0;

            var rows = System.IO.File.ReadAllLines("section.csv");
            for (int i = 2; i < rows.Length; i++)
            {
                rowsCounted++;
                var cols = rows[i].Split(',');

                int courseNumber = int.Parse(cols[2]);
                string subjectCode = cols[2];
                string instructorLink = cols[15];

                string name = cols[15];
                string [] splitName = name.Split('.');
                string firstName = splitName[0];
                string lastName = splitName[1];

                string semester = cols[1];
                bool monday = bool.Parse(cols[21]);
                bool tuesday = bool.Parse(cols[22]);
                bool wednesday = bool.Parse(cols[23]);
                bool thursday = bool.Parse(cols[24]);
                bool friday = bool.Parse(cols[25]);
                bool saturday = bool.Parse(cols[26]);
                bool sunday = bool.Parse(cols[27]);
                string building = cols[16];
                string room = cols[17];


                var instructor = _context.Instructors
                    .Where(q => q.ImportLink == instructorLink && q.FirstName == firstName && q.LastName == lastName)
                    .FirstOrDefault();

                if (instructor is null)
                {
                    instructor.ImportLink = instructorLink;
                    instructor.FirstName = firstName;
                    instructor.LastName = lastName;
                }

                var course = _context.Courses
                    .Where(q => q.CourseNum == courseNumber && q.SubjectCode == subjectCode)
                    .FirstOrDefault();

                if (course is null)
                {
                    course.CourseNum = courseNumber;
                    course.SubjectCode = subjectCode;
                }

                var schedule = _context.Schedules
                    .Where(q => q.Semester == semester && 
                        q.Monday == monday && 
                        q.Tuesday == tuesday && 
                        q.Wednesday == wednesday &&
                        q.Thursday == thursday &&
                        q.Friday == friday &&
                        q.Saturday == saturday &&
                        q.Sunday == sunday &&
                        q.Building == building &&
                        q.Room == room)
                    .FirstOrDefault();


                
                schedule = new Schedule
                {
                    Instructor = instructor,
                    Course = course,
                };

                //should I include this in the parenthesis above?
                schedule.Semester = semester;
                schedule.Monday = monday;
                schedule.Tuesday = tuesday;
                schedule.Wednesday = wednesday;
                schedule.Thursday = thursday;
                schedule.Friday = friday;
                schedule.Saturday = saturday;
                schedule.Sunday = sunday;
                schedule.Building = building;
                schedule.Room = room;

                _context.Courses.Add(course);
                //_context.SaveChanges();
                rowsImported++;
            }

            _context.SaveChanges();

            return View();
        }
    }
}
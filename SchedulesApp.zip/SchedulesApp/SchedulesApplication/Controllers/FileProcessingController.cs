﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.IO;
using SchedulesApplication.Models;
using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;


namespace SchedulesApplication.Controllers
{
    public class FileProcessingController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public async Task<IActionResult> ProcessFile()
        {
            int rowsCounted = 0, rowsImported = 0, rowsBad = 0;

            var rows = System.IO.File.ReadAllLines("section.csv");
            for (int i = 2; i < rows.Length; i++)
            {
                rowsCounted++;
                var cols = rows[i].Split(',');


                var course = new Course
                {
                    SubjectCode = cols[1],
                    CourseNum = int.Parse(cols[2]),

                };

                _context.Courses.Add(course);
                //_context.SaveChanges();
                rowsImported++;
            }

            _context.SaveChanges();

            return View();
        }
    }
}
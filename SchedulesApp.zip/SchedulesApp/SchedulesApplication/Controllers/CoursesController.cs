﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SchedulesApplication.Models;
using System.IO;


namespace SchedulesApplication.Controllers
{
    public class CoursesController : Controller
    {
        private readonly DatabaseContext _context;

        public CoursesController(DatabaseContext context)
        {
            _context = context;
        }

        // GET: Courses/Create
        public IActionResult Create()
        {
            return View();
        }
    }
}

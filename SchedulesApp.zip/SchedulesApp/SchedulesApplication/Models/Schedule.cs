﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchedulesApplication.Models
{
    public class Schedule
    {
        public int Id { get; set; }
        public int InstructorsId { get; set; }
        public int CoursesId { get; set; }
        public string Semester { get; set; }
        public bool Monday { get; set; }
        public bool Tuesday { get; set; }
        public bool Wednesday { get; set; }
        public bool Thursday { get; set; }
        public bool Friday { get; set; }
        public bool Saturday { get; set; }
        public bool Sunday { get; set; }
        public string Building { get; set; }
        public string Room { get; set; }


        //one
        public Instructor Instructor { get; set; }
        public Course Course { get; set; }

    }
}

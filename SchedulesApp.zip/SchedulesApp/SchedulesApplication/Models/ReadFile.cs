﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using CsvHelper;

namespace SchedulesApplication.Models
{
    public class ReadFile
    {
        string filePath = @"C:\Users\Jacqueline Ortiz\source\repos\SchedulesApplication\wwwroot\course.csv";

        





    }
}

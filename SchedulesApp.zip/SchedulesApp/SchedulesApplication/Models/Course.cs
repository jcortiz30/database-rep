﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchedulesApplication.Models
{
    public class Course
    {
        public int Id { get; set; }
        public string SubjectCode { get; set; }
        public int CourseNum { get; set; }


        //can have many schedules
        public ICollection<Schedule> Schedules { get; set; }
        
    }
}
